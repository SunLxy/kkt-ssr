// @ts-ignore
import styles from './App.module.css';
import './app.css';
const App = () => <div className={styles.warpper}>
    Welcome to KKT.
    <div className="btn">Btn</div>
  </div>;
export default App;