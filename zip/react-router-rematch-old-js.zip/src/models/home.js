import { createModel } from "@rematch/core";
export default createModel()({
  state: {
    test: 'home state test'
  },
  reducers: {
    updateState: (state, payload) => ({ ...state,
      ...payload
    })
  },
  effects: {}
});