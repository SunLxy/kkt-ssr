// @ts-ignore
import { init } from '@rematch/core';
import loading from '@rematch/loading';
import home from "./home";
import global from "./global";
import about from "./about";
import cookie from 'cookiejs';
export const models = {
  home,
  global,
  about
};
export const store = init({
  models,
  plugins: [loading(), {
    createMiddleware: () => () => next => async action => {
      if (typeof window !== 'undefined') {
        const token = cookie.get('token');

        if (token) {
          await cookie.set('token', token, 1);
        }
      }

      return next(action);
    }
  }]
});
export const {
  dispatch,
  addModel
} = store;
export default store;