import path from "path"
export default {
  output_path: path.join(process.cwd(), "build")
}