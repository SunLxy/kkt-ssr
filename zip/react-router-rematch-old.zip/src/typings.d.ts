declare module '*.css';
declare module '*.less';
declare module '*.svg';
declare module '*.png';
declare module 'http-proxy-middleware'